package kr.or.ddit.user.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.controller.Action;

public class UserController implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//db에서 조회되었다고 가정하고 가상의 리스트 객체 생성
		List<String> userList = new ArrayList<String>();
		userList.add("brown");
		userList.add("cony");
		userList.add("sally");
		
		request.setAttribute("userList", userList);
		request.getRequestDispatcher("./userList.jsp").forward(request, response);
	}

}
