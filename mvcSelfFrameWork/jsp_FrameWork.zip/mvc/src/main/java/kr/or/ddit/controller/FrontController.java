package kr.or.ddit.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//서블릿을 위해 프리퍼런스에서 런타임 체크(pom에 디펜던시로 추가 안한 까닭은 톰캣이 가지고 있고, 배포 안할 의도)

public class FrontController extends HttpServlet{
	// init -> 서비스에서(doGet, doXXX)호출 -> destory 
	// FrontController 는 get post 상관없이 "서비스"만 바라보면 된다 
	
	//매핑정보를 미리 만들(db 대신 MAp으로)
	Map<String, String> urlMapping = new HashMap<String, String>();
	public FrontController(){
		urlMapping.put("/main.do", "kr.or.ddit.main.web.MainController");
		urlMapping.put("/userList.do", "kr.or.ddit.user.web.UserController");
	}
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//url - controller를 맵핑해서 처리 한다 <- 매핑정보를 미리 만들어야한다(db 대신 MAp으로)
		String uri = request.getRequestURI();
		String controllerClass = urlMapping.get(uri);
		
		
		//controllerClass = kr.or.ddit.main.web.MainController
		try {
			Class clazz = Class.forName(controllerClass);	//<-- 객체지향 스러운 역할 
			Action action = (Action) clazz.newInstance();	
					// 들어오는 매핑 주소가 매번 리턴타입이 다를텐데.. 어떻게 리턴?
					// <- 새로 Action 인터페이스를 만들어 그 안에 있는 메서드로 처리
			
			//if 구문없이 처리 가능 
			action.execute(request,response); 		// 서블릿은 리퀘스트,리스폰즈를 항상 받으니까 파라미터 추가 
			
			
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		
		
	}
}
