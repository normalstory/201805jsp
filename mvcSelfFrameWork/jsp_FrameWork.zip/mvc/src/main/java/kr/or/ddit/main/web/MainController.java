package kr.or.ddit.main.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.controller.Action;

public class MainController implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//main.jsp 처리되도록 위임 
		request.getRequestDispatcher("/main.jsp").forward(request, response);
		
	}

}
